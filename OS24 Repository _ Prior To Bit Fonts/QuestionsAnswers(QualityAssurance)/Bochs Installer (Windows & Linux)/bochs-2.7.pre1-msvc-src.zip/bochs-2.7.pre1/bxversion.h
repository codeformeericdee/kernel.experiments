/////////////////////////////////////////////////////////////////////////
// This file is checked in as bxversion.h.in.  The configure script
// substitutes variables and creates bxversion.h.
/////////////////////////////////////////////////////////////////////////

#define VERSION       "2.7.pre1"
#define VER_SVNFLAG   0
#define REL_STRING    "Built from SVN snapshot on June 13, 2021"
#define REL_TIMESTAMP "Sun Jun 13 07:15:00 CEST 2021"
